"""Bounded Shipment Document Picker V1 catalog and persistence acceptance."""

from __future__ import annotations

import pytest

from core import database
from core.shipment_document_catalog import (
    SHIPMENT_DOCUMENT_CATALOG,
    SelectionValidationError,
    ShipmentDocumentTemplate,
    project_catalog,
    project_selected_template_ids,
    validate_selected_template_ids,
)
from views import logi_real_data as rd
from views import logi_sandbox
from views import logi_view_model as vm

SHIPMENT_ID = "LO-0308"


@pytest.fixture()
def staging():
    import streamlit as st

    logi_sandbox.reset_backend()
    assert logi_sandbox.ensure_backend() == logi_sandbox.SANDBOX_TRANSPORT
    st.session_state["current_user"] = dict(logi_sandbox.STAGING_ACTOR)
    st.session_state.pop(vm.LAST_WRITES_KEY, None)
    yield
    st.session_state["current_user"] = dict(logi_sandbox.STAGING_ACTOR)
    logi_sandbox.reset_backend()


def _available_policy(*_args, **_kwargs):
    return {
        "catalog": project_catalog(
            contract_templates_available=True,
            pxk_template_available=True,
            storage_configured=True,
        ),
        "canSaveSelection": True,
        "canGenerate": True,
        "storageConfigured": True,
    }


def _dispatch(name: str, payload: dict, seq: int = 1) -> dict:
    outcomes = vm.consume_phase_b_triggers(
        {"seq": seq - 1},
        {name: {"seq": seq, "event": name, "payload": payload}},
    )
    assert len(outcomes) == 1
    return outcomes[0]


def test_catalog_is_small_stable_and_fail_closed():
    # Issue #168 adds exactly ONE Owner-sample pilot (FORM_07) to the V1 set;
    # the remaining six samples stay out until their own evidence-driven slices.
    assert [row.id for row in SHIPMENT_DOCUMENT_CATALOG] == ["HDNT", "PL", "HDMB", "PXK", "GNT", "FORM_07"]
    assert {row.adapter for row in SHIPMENT_DOCUMENT_CATALOG} == {
        "CONTRACT_DOCGEN", "PXK_DOCGEN", "GNT_BUILDER", "FORM07_DOCGEN"
    }
    assert validate_selected_template_ids(["GNT", "HDMB"]) == ["HDMB", "GNT"]
    assert project_selected_template_ids(["PXK", "NOT-IN-CATALOG", "HDNT", 7]) == ["HDNT", "PXK"]

    inactive = ShipmentDocumentTemplate("OLD", "Old", "", "UNKNOWN_ADAPTER", "OLD", active=False)
    with pytest.raises(SelectionValidationError, match="không có trong danh mục"):
        validate_selected_template_ids(["NOT-IN-CATALOG"])
    with pytest.raises(SelectionValidationError, match="bị chọn lặp"):
        validate_selected_template_ids(["PXK", "PXK"])
    with pytest.raises(SelectionValidationError, match="không hoạt động"):
        validate_selected_template_ids(["OLD"], catalog=(*SHIPMENT_DOCUMENT_CATALOG, inactive))


def test_catalog_availability_is_server_projected_and_unknown_adapter_stays_closed():
    extra = ShipmentDocumentTemplate("NEXT", "Next", "", "UNSUPPORTED", "NEXT")
    rows = project_catalog(
        contract_templates_available=False,
        pxk_template_available=True,
        storage_configured=False,
        catalog=(*SHIPMENT_DOCUMENT_CATALOG, extra),
    )
    by_id = {row["id"]: row for row in rows}
    assert by_id["HDNT"]["available"] is False
    assert by_id["PXK"]["available"] is False
    assert by_id["GNT"]["available"] is False
    assert by_id["NEXT"]["active"] is True
    assert by_id["NEXT"]["available"] is False
    assert by_id["NEXT"]["availabilityReason"]

    contract_without_attachment_storage = project_catalog(
        contract_templates_available=True,
        pxk_template_available=True,
        storage_configured=False,
    )[0]
    assert contract_without_attachment_storage["available"] is True
    assert by_id["PXK"]["available"] is False


def test_selection_save_readback_and_unselect_preserve_generated_history(staging, monkeypatch):
    monkeypatch.setattr(vm, "_shipment_document_picker_policy", _available_policy)
    shipment = vm.read_shipment(SHIPMENT_ID)
    assert shipment is not None
    version = int(shipment.get("version") or 0)

    # Existing generated output is independent history, not part of the
    # selection field; deselecting PXK must leave this canonical row untouched.
    db = database.get_db()
    history = {
        "_id": f"{SHIPMENT_ID}-PXK::R1",
        "id": f"{SHIPMENT_ID}-PXK::R1",
        "document_id": f"{SHIPMENT_ID}-PXK",
        "shipment_id": SHIPMENT_ID,
        "document_type": "PXK",
        "generation_revision": 1,
        "status": "GENERATED",
        "file_name": "PXK_LO-0308_R1.xlsx",
        "output_hash": "fixture-output-hash",
    }
    db["docgen_documents"].insert_one(dict(history))
    before_collections = set(db.list_collection_names())

    saved = _dispatch("shipment_document_selection_save", {
        "shipmentId": SHIPMENT_ID,
        "requestId": "SDOC-SAVE-1",
        "expectedVersion": version,
        "selectedTemplateIds": ["PXK", "HDNT"],
    })
    assert saved["ok"], saved
    assert saved["gate"] == "SAVED"
    assert saved["readback"]["selectedDocumentTemplateIds"] == ["HDNT", "PXK"]
    fresh = vm.read_shipment(SHIPMENT_ID)
    assert fresh is not None
    assert fresh["document_template_ids"] == ["HDNT", "PXK"]
    assert int(fresh.get("version") or 0) > version
    assert db["docgen_documents"].find_one({"id": history["id"]}, {"_id": 0})["output_hash"] == "fixture-output-hash"

    deselect = _dispatch("shipment_document_selection_save", {
        "shipmentId": SHIPMENT_ID,
        "requestId": "SDOC-SAVE-2",
        "expectedVersion": int(fresh.get("version") or 0),
        "selectedTemplateIds": ["HDNT"],
    }, seq=2)
    assert deselect["ok"], deselect
    latest = vm.read_shipment(SHIPMENT_ID)
    assert latest is not None
    assert latest["document_template_ids"] == ["HDNT"]
    assert db["docgen_documents"].find_one({"id": history["id"]}, {"_id": 0})["output_hash"] == "fixture-output-hash"
    assert set(db.list_collection_names()) == before_collections | {"audit_logs"}
    assert "shipment_document_selections" not in db.list_collection_names()


def test_selection_rejects_unknown_inactive_and_stale_version_without_mutation(staging, monkeypatch):
    # Issue #195 — selection and generation availability are separate
    # concepts. An active + known template may be selected/tracked even when
    # the generator is currently unavailable; unknown/inactive/stale still
    # fail closed with no mutation.
    from dataclasses import replace

    monkeypatch.setattr(vm, "_shipment_document_picker_policy", _available_policy)
    shipment = vm.read_shipment(SHIPMENT_ID)
    assert shipment is not None
    original_ids = shipment.get("document_template_ids")
    version = int(shipment.get("version") or 0)

    unknown = _dispatch("shipment_document_selection_save", {
        "shipmentId": SHIPMENT_ID,
        "requestId": "SDOC-UNKNOWN",
        "expectedVersion": version,
        "selectedTemplateIds": ["FAKE"],
    })
    assert not unknown["ok"]
    assert unknown["gate"] == "UNKNOWN_TEMPLATE"

    real_catalog = vm._effective_document_catalog()
    inactive_catalog = tuple(
        replace(template, active=False) if template.id == "PXK" else template
        for template in real_catalog
    )
    monkeypatch.setattr(vm, "_effective_document_catalog", lambda: inactive_catalog)
    inactive = _dispatch("shipment_document_selection_save", {
        "shipmentId": SHIPMENT_ID,
        "requestId": "SDOC-INACTIVE",
        "expectedVersion": version,
        "selectedTemplateIds": ["PXK"],
    }, seq=2)
    assert not inactive["ok"]
    assert inactive["gate"] == "INACTIVE_TEMPLATE"
    monkeypatch.undo()

    def pxk_unavailable(*_args, **_kwargs):
        policy = _available_policy()
        for row in policy["catalog"]:
            if row["id"] == "PXK":
                row["available"] = False
                row["availabilityReason"] = "Mẫu PXK đang khóa trong test."
        return policy

    monkeypatch.setattr(vm, "_shipment_document_picker_policy", pxk_unavailable)
    unavailable = _dispatch("shipment_document_selection_save", {
        "shipmentId": SHIPMENT_ID,
        "requestId": "SDOC-UNAVAILABLE",
        "expectedVersion": version,
        "selectedTemplateIds": ["PXK"],
    }, seq=3)
    # Issue #195: active + known + currently-unavailable SAVES (tracking).
    assert unavailable["ok"], unavailable.get("error")
    assert unavailable["gate"] == "SAVED"
    assert "PXK" in unavailable["readback"]["selectedDocumentTemplateIds"]
    fresh = vm.read_shipment(SHIPMENT_ID)
    assert fresh is not None
    assert "PXK" in (fresh.get("document_template_ids") or [])

    new_version = int(fresh.get("version") or 0)
    assert new_version == version + 1
    stale = _dispatch("shipment_document_selection_save", {
        "shipmentId": SHIPMENT_ID,
        "requestId": "SDOC-STALE",
        "expectedVersion": version,
        "selectedTemplateIds": ["HDNT"],
    }, seq=4)
    assert not stale["ok"]
    assert stale["gate"] == "STALE_VERSION"

    refinal = vm.read_shipment(SHIPMENT_ID)
    assert refinal is not None
    assert int(refinal.get("version") or 0) == new_version
    assert "PXK" in (refinal.get("document_template_ids") or [])


def test_generation_stays_refused_after_unavailable_template_selected(staging, monkeypatch):    # Issue #195 — the selection write no longer couples to availability, but
    # every generation handler keeps its own fail-closed readiness gates.
    monkeypatch.setattr(vm, "_shipment_document_picker_policy", _available_policy)
    shipment = vm.read_shipment(SHIPMENT_ID)
    assert shipment is not None
    version = int(shipment.get("version") or 0)

    saved = _dispatch("shipment_document_selection_save", {
        "shipmentId": SHIPMENT_ID,
        "requestId": "SDOC-195-GEN",
        "expectedVersion": version,
        "selectedTemplateIds": ["PXK"],
    })
    assert saved["ok"], saved.get("error")

    # Confirm a real commercial flow first so the generation attempt reaches
    # its own readiness gates (not the flow gate).
    flow = _dispatch("shipment_commercial_flow_save", {
        "shipmentId": SHIPMENT_ID,
        "requestId": "FLOW-195-GEN",
        "mode": "TT_ENTRUSTED_DIRECT",
        "companyId": "TT-COMPANY",
    }, seq=2)
    assert flow["ok"], flow.get("error")

    # A real generation attempt is still refused by its own readiness gates
    # (here: the shipment is not delivered) until readiness is satisfied.
    refused = _dispatch("pxk_generate", {
        "shipmentId": SHIPMENT_ID,
        "requestId": "PXK-GEN-195",
        "pxkNo": "PXK-2026-0195",
        "pxkDate": "2026-10-11",
    }, seq=3)
    assert not refused["ok"]
    assert refused["gate"] == "BLOCKED_NOT_DELIVERED", refused


def test_read_projection_exposes_durable_ids_existing_gates_and_generated_history(staging):
    shipment = vm.read_shipment(SHIPMENT_ID)
    assert shipment is not None
    shipment["document_template_ids"] = ["PXK", "GNT", "HDNT"]
    record_id = f"{SHIPMENT_ID}-PXK::R1"
    generated = {
        "id": record_id,
        "document_id": f"{SHIPMENT_ID}-PXK",
        "shipment_id": SHIPMENT_ID,
        "document_type": "PXK",
        "generation_revision": 1,
        "status": "GENERATED",
        "output_file_name": "PXK_LO-0308_R1.xlsx",
        "output_hash": "fixture-output-hash",
    }
    projection = rd.shipment_projection(
        shipment,
        docgen_documents={SHIPMENT_ID: {record_id: generated}},
        linked_contracts={SHIPMENT_ID.upper(): {}},
        attachments={SHIPMENT_ID: []},
    )
    assert projection["selectedDocumentTemplateIds"] == ["HDNT", "PXK", "GNT"]
    assert projection["importInfo"]["gnt"]["readiness"]["state"] == "MISSING_INFO"
    assert projection["pxk"]["readiness"]["state"] == "MISSING_INFO"
    if not bool((shipment.get("data", {}).get("2.7") or {}).get("is_delivered")):
        assert projection["pxk"]["missingDeliveryFacts"] == []
    assert projection["pxk"]["documentHistory"][0]["recordId"] == record_id
    assert projection["pxk"]["documentHistory"][0]["fileName"] == "PXK_LO-0308_R1.xlsx"


def test_selection_writer_and_single_handler_are_registered():
    assert vm.PHASE_B_EVENTS == set(vm._HANDLERS)
    assert vm._HANDLERS["shipment_document_selection_save"] is vm._handle_shipment_document_selection_save


def test_customer_self_existing_customer_id_confirms_without_reselecting(staging):
    """Issue #197 — a normal created lot already knows its customer."""
    from core import database as core_database

    db = core_database.get_db()
    db["shipments"].update_one(
        {"id": SHIPMENT_ID},
        {"$set": {"customer_id": "CUST-ANPHAT", "customer": "An Phát JSC", "client": "An Phát JSC"}},
    )

    confirmed = _dispatch("shipment_commercial_flow_save", {
        "shipmentId": SHIPMENT_ID,
        "requestId": "FLOW-SELF-197-MODERN",
        "mode": "CUSTOMER_SELF",
    })
    assert confirmed["ok"], confirmed.get("error")
    assert confirmed["persisted"]["customerId"] == "CUST-ANPHAT"
    assert confirmed["persisted"]["commercialFlow"]["mode"] == "CUSTOMER_SELF"
    assert confirmed["readback"]["commercialFlow"]["legalImporterName"] == "An Phát JSC"


def test_customer_self_legacy_unique_name_autolinks_and_confirms_atomically(staging):
    """Issue #197 — do not ask for the same customer twice.

    A legacy shipment may have the canonical customer NAME but no customer_id.
    If that name has exactly one exact master match, CUSTOMER_SELF links that
    id and confirms the flow in the same atomic shipment write.
    """
    from core import database as core_database

    db = core_database.get_db()
    db["shipments"].update_one(
        {"id": SHIPMENT_ID},
        {"$set": {"customer_id": "", "customer": "An Phát JSC", "client": "An Phát JSC"}},
    )
    before = vm.read_shipment(SHIPMENT_ID)
    assert before is not None
    before_version = int(before.get("version") or 0)
    assert not before.get("customer_id")

    confirmed = _dispatch("shipment_commercial_flow_save", {
        "shipmentId": SHIPMENT_ID,
        "requestId": "FLOW-SELF-197-UNIQUE",
        "mode": "CUSTOMER_SELF",
    })
    assert confirmed["ok"], confirmed.get("error")
    assert confirmed["persisted"]["customerId"] == "CUST-ANPHAT"
    assert confirmed["persisted"]["commercialFlow"]["mode"] == "CUSTOMER_SELF"

    fresh = vm.read_shipment(SHIPMENT_ID)
    assert fresh is not None
    assert fresh.get("customer_id") == "CUST-ANPHAT"
    assert int(fresh.get("version") or 0) == before_version + 1
    assert confirmed["readback"]["commercialFlow"]["confirmed"] is True
    assert confirmed["readback"]["commercialFlow"]["legalImporterName"] == "An Phát JSC"


def test_customer_self_legacy_ambiguous_name_refuses_and_requests_one_choice(staging, monkeypatch):
    """Exact-name ambiguity stays fail-closed; no legal identity is guessed."""
    from core import database as core_database

    db = core_database.get_db()
    db["shipments"].update_one(
        {"id": SHIPMENT_ID},
        {"$set": {"customer_id": "", "customer": "Công ty Trùng Tên", "client": "Công ty Trùng Tên"}},
    )
    monkeypatch.setattr(core_database, "load_customers", lambda: {
        "CUST-DUP-1": {"id": "CUST-DUP-1", "name": "Công ty Trùng Tên"},
        "CUST-DUP-2": {"id": "CUST-DUP-2", "name": "Công ty Trùng Tên"},
    })

    refused = _dispatch("shipment_commercial_flow_save", {
        "shipmentId": SHIPMENT_ID,
        "requestId": "FLOW-SELF-197-AMB",
        "mode": "CUSTOMER_SELF",
    })
    assert not refused["ok"]
    assert refused["gate"] == "COMMERCIAL_FLOW_REFUSED"
    assert refused["needsCustomerChoice"] is True
    assert "trùng tên" in refused["error"]
    fresh = vm.read_shipment(SHIPMENT_ID)
    assert fresh is not None
    assert not fresh.get("customer_id")


def test_customer_self_explicit_master_choice_repairs_legacy_link_in_same_save(staging):
    """When exact matching cannot decide, one explicit master id is enough."""
    from core import database as core_database

    db = core_database.get_db()
    db["shipments"].update_one(
        {"id": SHIPMENT_ID},
        {"$set": {"customer_id": "", "customer": "Tên cũ chưa chuẩn", "client": "Tên cũ chưa chuẩn"}},
    )

    confirmed = _dispatch("shipment_commercial_flow_save", {
        "shipmentId": SHIPMENT_ID,
        "requestId": "FLOW-SELF-197-EXPLICIT",
        "mode": "CUSTOMER_SELF",
        "customerId": "CUST-ANPHAT",
    })
    assert confirmed["ok"], confirmed.get("error")
    assert confirmed["persisted"]["customerId"] == "CUST-ANPHAT"
    fresh = vm.read_shipment(SHIPMENT_ID)
    assert fresh is not None
    assert fresh.get("customer_id") == "CUST-ANPHAT"
    assert fresh.get("customer") == "An Phát JSC"


# ---------------------------------------------------------------------------
# Issue #195 follow-up — requestId echo on shipment_customer_save.
#
# The UI mints a requestId per GÁN intent and settles pending only on a
# lastWrites row whose requestId matches. The backend must echo it on every
# success/refusal, but must NOT make it mandatory: the legacy header editor
# still dispatches shipment_customer_save without one.
# ---------------------------------------------------------------------------

def test_customer_save_echoes_request_id_on_success(staging):
    out = _dispatch("shipment_customer_save", {
        "shipmentId": SHIPMENT_ID,
        "requestId": "CUST-RID-OK",
        "customerId": "CUST-ANPHAT",
    })
    assert out["ok"], out.get("error")
    assert out["requestId"] == "CUST-RID-OK"
    assert out["persisted"]["customerId"] == "CUST-ANPHAT"


def test_customer_save_echoes_request_id_on_unknown_customer_refusal(staging):
    out = _dispatch("shipment_customer_save", {
        "shipmentId": SHIPMENT_ID,
        "requestId": "CUST-RID-UNKNOWN",
        "customerId": "CUST-KHONGTONTAI",
    })
    assert not out["ok"]
    assert "danh bạ" in out["error"]
    assert out["requestId"] == "CUST-RID-UNKNOWN"


def test_customer_save_echoes_request_id_on_rbac_refusal(staging):
    import streamlit as st

    st.session_state["current_user"] = {
        "username": "viewer.rid", "full_name": "viewer.rid",
        "role": "viewer", "user_id": "ID-viewer.rid",
    }
    out = _dispatch("shipment_customer_save", {
        "shipmentId": SHIPMENT_ID,
        "requestId": "CUST-RID-RBAC",
        "customerId": "CUST-ANPHAT",
    })
    assert not out["ok"]
    assert "RBAC" in out["error"]
    assert out["requestId"] == "CUST-RID-RBAC"


def test_customer_save_echoes_request_id_on_writer_refusal(staging, monkeypatch):
    import core.database as core_database

    monkeypatch.setattr(core_database, "update_shipment_customer",
                        lambda *args, **kwargs: False)
    out = _dispatch("shipment_customer_save", {
        "shipmentId": SHIPMENT_ID,
        "requestId": "CUST-RID-WRITE",
        "customerId": "CUST-HONGHA",
    })
    assert not out["ok"]
    assert out["requestId"] == "CUST-RID-WRITE"


def test_customer_save_request_id_not_mandatory_for_legacy_header_editor(staging):
    # The legacy header editor dispatches without a requestId; it must keep
    # working and the echo degrades to "".
    out = _dispatch("shipment_customer_save", {
        "shipmentId": SHIPMENT_ID,
        "customerId": "CUST-HONGHA",
    })
    assert out["ok"], out.get("error")
    assert out["requestId"] == ""
    assert out["persisted"]["customerId"] == "CUST-HONGHA"
